package fr.tryxee62dev.idigcalculatorapp

import android.app.AlertDialog
import android.app.LocaleManager
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import android.content.Intent
import android.os.Build
import android.os.LocaleList
import java.util.Locale

class ButtonsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.buttons)

        val label = findViewById<TextView>(R.id.label)
        val option1_b = findViewById<Button>(R.id.option1)
        val option2_b = findViewById<Button>(R.id.option2)

        val next1 = intent.getStringExtra("next1")
        val next2 = intent.getStringExtra("next2")
        val code = intent.getStringExtra("code")
        val lang = intent.getStringExtra("lang")

        fun setCurrentLocale(context: Context, languageTag: String) {
            val localeParts = languageTag.split("_")
            val languageCode = localeParts[0] // "fr"
            val countryCode = if (localeParts.size > 1) localeParts[1] else "" // "FR"

            val locale = if (countryCode.isNotEmpty()) Locale(languageCode, countryCode) else Locale(languageCode)
            Locale.setDefault(locale)

            val config = context.resources.configuration
            config.setLocale(locale)
            config.setLayoutDirection(locale)

            context.resources.updateConfiguration(config, context.resources.displayMetrics)
        }


//        fun setCurrentLocale(context: Context, languageCode: String) {
//            val locale = Locale(languageCode)
//            Locale.setDefault(locale)
//
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//                // Android 13+ (API 33) : Utilisation de LocaleManager
//                val localeManager = context.getSystemService(LocaleManager::class.java)
//                localeManager?.applicationLocales = LocaleList.forLanguageTags(languageCode)
//            } else {
//                // Android 7+ (API 24 - 32) : Utilisation de createConfigurationContext()
//                val config = context.resources.configuration
//                config.setLocale(locale)
//                context.createConfigurationContext(config)
//            }
//        }

        setCurrentLocale(this, lang.toString())

        val res = resources

        val key = intent.getStringExtra("frame_label")
        if (key != null) {
            val resId = resources.getIdentifier(key, "string", packageName)
            if (resId != 0) {
                label.text = getString(resId)
            } else {
                label.text = "Error : Text not found !"
            }
        } else {
            label.text = "Error : Text key not gived !"
        }

        val option1_key = intent.getStringExtra("option1")
        if (option1_key != null) {
            val resId = resources.getIdentifier(option1_key, "string", packageName)
            if (resId != 0) {
                option1_b.text = getString(resId)
            } else {
                option1_b.text = "Error : Option1 doesn't exist !"
            }
        } else {
            option1_b.text = "Error : Option1 key not gived !"
        }

        val option2_key = intent.getStringExtra("option2")
        if (option2_key != null) {
            val resId = resources.getIdentifier(option2_key, "string", packageName)
            if (resId != 0) {
                option2_b.text = res.getString(res.getIdentifier(intent.getStringExtra("option2"), "string", packageName))
            } else {
                option2_b.text = "Error : Option2 doesn't exist !"
            }
        } else {
            option2_b.text = "Error : Text key not gived !"
        }


        /*
        IntentButton.putExtra("frame_label", frame_label)
                IntentButton.putExtra("option_yes", splitted_buttons_options[0])
                IntentButton.putExtra("option_no", splitted_buttons_options[1])
         */


        fun returnResult(response: String) {
            val resultIntent = Intent().apply {
                putExtra("response", response)
            }
            setResult(RESULT_OK, resultIntent)
            finish() // Ferme Activity2 et retourne à Activity1
        }

        option1_b.setOnClickListener {
            returnResult("$code|${option1_b.text}|$next1")
        }

        option2_b.setOnClickListener {
            returnResult("$code|${option2_b.text}|$next2")
        }
    }
}