package fr.tryxee62dev.idigcalculatorapp

import android.app.AlertDialog
import android.app.LocaleManager
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import android.content.Intent
import android.os.Build
import android.os.LocaleList
import android.view.View
import android.widget.Toast
import java.util.Locale

class ResponseActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.response_intent)

        val textView_surveyor_text = findViewById<TextView>(R.id.textView_surveyor)

        val lang = intent.getStringExtra("lang")
        val D13 = findViewById<TextView>(R.id.D13)
        val D14 = findViewById<TextView>(R.id.D14)
        val D15 = findViewById<TextView>(R.id.D15)
        val D16 = findViewById<TextView>(R.id.D16)
        val D17 = findViewById<TextView>(R.id.D17)
        val D18 = findViewById<TextView>(R.id.D18)
        val D19 = findViewById<TextView>(R.id.D19)
        val D20 = findViewById<TextView>(R.id.D20)
        val D21 = findViewById<TextView>(R.id.D21)
        val D22 = findViewById<TextView>(R.id.D22)
        val restart_b = findViewById<Button>(R.id.restart)

        val D13_double = intent.getDoubleExtra("D13", -1.0)
        val D14_double = intent.getDoubleExtra("D14", -1.0)
        val D15_double = intent.getDoubleExtra("D15", -1.0)
        val D16_double = intent.getDoubleExtra("D16", -1.0)
        val D17_double = intent.getDoubleExtra("D17", -1.0)
        val D18_double = intent.getDoubleExtra("D18", -1.0)
        val D19_double = intent.getDoubleExtra("D19", -1.0)
        val D20_double = intent.getDoubleExtra("D20", -1.0)
        val D21_double = intent.getDoubleExtra("D21", -1.0)
        val D22_double = intent.getDoubleExtra("D22", -1.0)
        val invisible = intent.getStringExtra("invisible")
        val devise = intent.getStringExtra("devise")

        if (invisible == "true") {
            textView_surveyor_text.visibility = View.INVISIBLE
            D13.visibility = View.INVISIBLE
        } else if (invisible == "false") {
            textView_surveyor_text.visibility = View.VISIBLE
            D13.visibility = View.VISIBLE
        } else {
            return
        }

        fun setCurrentLocale(context: Context, languageTag: String) {
            val localeParts = languageTag.split("_")
            val languageCode = localeParts[0] // "fr"
            val countryCode = if (localeParts.size > 1) localeParts[1] else "" // "FR"

            val locale = if (countryCode.isNotEmpty()) Locale(languageCode, countryCode) else Locale(languageCode)
            Locale.setDefault(locale)

            val config = context.resources.configuration
            config.setLocale(locale)
            config.setLayoutDirection(locale)

            context.resources.updateConfiguration(config, context.resources.displayMetrics)
        }

        setCurrentLocale(this, lang.toString())

        D13.text = String.format("%.2f", D13_double) + devise.toString()
        D14.text = String.format("%.2f", D14_double) + devise.toString()
        D15.text = String.format("%.2f", D15_double) + devise.toString()
        D16.text = String.format("%.2f", D16_double) + devise.toString()
        D17.text = String.format("%.2f", D17_double) + devise.toString()
        D18.text = String.format("%.2f", D18_double) + devise.toString()
        D19.text = String.format("%.2f", D19_double)
        D20.text = String.format("%.2f", D20_double)
        D21.text = String.format("%.2f", D21_double) + devise.toString()
        D22.text = String.format("%.2f", D22_double) + devise.toString()

        fun returnResult(response: String) {
            val resultIntent = Intent().apply {
                putExtra("response", response)
            }
            setResult(RESULT_OK, resultIntent)
            finish() // Ferme Activity2 et retourne à Activity1
        }

        restart_b.setOnClickListener {
            returnResult("restart")
        }

    }
}