package fr.tryxee62dev.idigcalculatorapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import android.os.LocaleList
import android.content.Context
import android.app.LocaleManager
import android.os.Build
import android.content.Intent
import java.util.Locale

class LangActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.lang_activity)

        var language_selected = ""

        val current_language = findViewById<TextView>(R.id.default_language)
        val en_uk_b = findViewById<Button>(R.id.en_us_b)
        val french_b = findViewById<Button>(R.id.french_b)
        val german_b = findViewById<Button>(R.id.german_b)
        val en_us_b = findViewById<Button>(R.id.en_uk_b)
        val international_b = findViewById<Button>(R.id.international_b)
        val valider_button = findViewById<Button>(R.id.valider_button)

        fun returnResult(response: String) {
            val resultIntent = Intent().apply {
                putExtra("response", response)
            }
            setResult(RESULT_OK, resultIntent)
            finish() // Ferme Activity2 et retourne à Activity1
        }

        fun setCurrentLocale(context: Context, languageTag: String) {
            val localeParts = languageTag.split("_")
            val languageCode = localeParts[0] // "fr"
            val countryCode = if (localeParts.size > 1) localeParts[1] else "" // "FR"

            val locale = if (countryCode.isNotEmpty()) Locale(languageCode, countryCode) else Locale(languageCode)
            Locale.setDefault(locale)

            val config = context.resources.configuration
            config.setLocale(locale)
            config.setLayoutDirection(locale)

            context.resources.updateConfiguration(config, context.resources.displayMetrics)
        }

        language_selected = Locale.getDefault().toString()
        if (language_selected == "") {
            language_selected = "zz_ZZ"
        }

        if (language_selected == "en_GB") {
            current_language.text = "English (UK)"
        } else if (language_selected == "en_US") {
            current_language.text = "English (US)"
        } else if (language_selected == "zz_ZZ") {
            current_language.text = "International"
        } else if (language_selected == Locale.FRANCE.toString()) {
            current_language.text = "Français"
        } else if (language_selected == Locale.GERMANY.toString()) {
            current_language.text = "Deutsch"
        }

        en_uk_b.setOnClickListener {
            setCurrentLocale(this, "en_GB")
            //finish()
            //startActivity(intent)
            language_selected = "en_GB"
            recreate()
        }

        french_b.setOnClickListener {
            setCurrentLocale(this, Locale.FRANCE.toString())
            //finish()
            language_selected = Locale.FRANCE.toString()
            recreate()
        }

        german_b.setOnClickListener {
            setCurrentLocale(this, Locale.GERMANY.toString())
            //finish()
            //startActivity(intent)
            language_selected = Locale.GERMANY.toString()
            recreate()
        }

        en_us_b.setOnClickListener {
            setCurrentLocale(this, "en_US")
            //finish()
            //startActivity(intent)
            language_selected = "en_US"
            recreate()
        }

        international_b.setOnClickListener {
            setCurrentLocale(this, "zz_ZZ") // code fictif pour l'international
            language_selected = "zz_ZZ"
            recreate()
        }

        valider_button.setOnClickListener {
            if (language_selected == "zz_ZZ" ||
                language_selected == "en_US" ||
                language_selected == "en_GB" ||
                language_selected == Locale.GERMANY.toString() ||
                language_selected == Locale.FRANCE.toString())
            {
                returnResult("lang|" + language_selected)
            } else {
                current_language.text = "Your language is not supported : Please select a language !"
            }

        }
    }
}