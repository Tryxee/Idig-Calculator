package fr.tryxee62dev.idigcalculatorapp

import android.app.LocaleManager
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import android.content.Intent
import android.os.Build
import android.os.LocaleList
import android.widget.EditText
import android.widget.Toast
import java.util.Locale

class double_entryActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.double_entry)

        val label = findViewById<TextView>(R.id.label)
        val number_entry = findViewById<EditText>(R.id.number_entry)
        val Validate_b = findViewById<Button>(R.id.option1)
        val indicateur_text = findViewById<TextView>(R.id.indicateur)
        val code = intent.getStringExtra("code")
        val next = intent.getStringExtra("next")
        val lang = intent.getStringExtra("lang")

        fun setCurrentLocale(context: Context, languageTag: String) {
            val localeParts = languageTag.split("_")
            val languageCode = localeParts[0] // "fr"
            val countryCode = if (localeParts.size > 1) localeParts[1] else "" // "FR"

            val locale = if (countryCode.isNotEmpty()) Locale(languageCode, countryCode) else Locale(languageCode)
            Locale.setDefault(locale)

            val config = context.resources.configuration
            config.setLocale(locale)
            config.setLayoutDirection(locale)

            context.resources.updateConfiguration(config, context.resources.displayMetrics)
        }

        setCurrentLocale(this, lang.toString())

        val label_key = intent.getStringExtra("frame_label")
        if (label_key != null) {
            val resId = resources.getIdentifier(label_key, "string", packageName)
            if (resId != 0) {
                label.text = getString(resId)
            } else {
                label.text = "Error : Option not found !"
            }
        } else {
            label.text = "Error : Option key not gived !"
        }

        val option_key = intent.getStringExtra("option")
        if (option_key != null) {
            val resId = resources.getIdentifier(option_key, "string", packageName)
            if (resId != 0) {
                if (option_key == "script_replace") {
                    indicateur_text.text = ""
                } else {
                    indicateur_text.text = getString(resId)
                }
            } else {
                indicateur_text.text = ""
            }
        } else {
            number_entry.hint = "Error : Text key not gived !"
        }

        if (next == "calculate") {
            val resId = resources.getIdentifier("calculate", "string", packageName)
            if (resId != 0) {
                Validate_b.text = getString(resId)
            } else {
                //Error
            }
        } else {
            val resId = resources.getIdentifier("validate", "string", packageName)
            if (resId != 0) {
                Validate_b.text = getString(resId)
            } else {
                //Error
            }
        }



        fun returnResult(response: String) {
            val resultIntent = Intent().apply {
                putExtra("response", response)
            }
            setResult(RESULT_OK, resultIntent)
            finish() // Ferme Activity2 et retourne à Activity1
        }

        Validate_b.setOnClickListener {
            val numbeur: String = number_entry.text.toString()
            if (numbeur != "") {
                returnResult("$code|$numbeur#Double|$next")
            }
            else {
                Toast.makeText(this, resources.getIdentifier(R.string.worst_entry_double.toString(), "string", packageName), Toast.LENGTH_LONG).show()
            }
        }

    }
}