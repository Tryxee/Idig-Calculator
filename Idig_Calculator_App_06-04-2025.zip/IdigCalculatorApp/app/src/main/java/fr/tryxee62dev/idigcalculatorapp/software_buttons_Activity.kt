package fr.tryxee62dev.idigcalculatorapp

import android.app.LocaleManager
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import android.content.Intent
import android.os.Build
import android.os.LocaleList
import java.util.Locale

class software_buttons_Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.software_buttons)

        val label = findViewById<TextView>(R.id.label)
        val option1_b = findViewById<Button>(R.id.option1)
        val option2_b = findViewById<Button>(R.id.option2)
        val option3_b = findViewById<Button>(R.id.option3)
        val option4_b = findViewById<Button>(R.id.option4)

        val code = intent.getStringExtra("code")
        val lang = intent.getStringExtra("lang")
        val option2 = intent.getStringExtra("option2")
        val option3 = intent.getStringExtra("option3")
        val option4 = intent.getStringExtra("option4")
        val option5 = intent.getStringExtra("option5")

        val next2 = intent.getStringExtra("next2")
        val next3 = intent.getStringExtra("next3")
        val next4 = intent.getStringExtra("next4")
        val next5 = intent.getStringExtra("next5")

        option1_b.text = option2
        option2_b.text = option3
        option3_b.text = option4
        option4_b.text = option5

        fun setCurrentLocale(context: Context, languageTag: String) {
            val localeParts = languageTag.split("_")
            val languageCode = localeParts[0] // "fr"
            val countryCode = if (localeParts.size > 1) localeParts[1] else "" // "FR"

            val locale = if (countryCode.isNotEmpty()) Locale(languageCode, countryCode) else Locale(languageCode)
            Locale.setDefault(locale)

            val config = context.resources.configuration
            config.setLocale(locale)
            config.setLayoutDirection(locale)

            context.resources.updateConfiguration(config, context.resources.displayMetrics)
        }

        setCurrentLocale(this, lang.toString())

        val key = intent.getStringExtra("frame_label")
        if (key != null) {
            val resId = resources.getIdentifier(key, "string", packageName)
            if (resId != 0) {
                label.text = getString(resId)
            } else {
                label.text = "Error : Text not found !"
            }
        } else {
            label.text = "Error : Text key not gived !"
        }

        fun returnResult(response: String) {
            val resultIntent = Intent().apply {
                putExtra("response", response)
            }
            setResult(RESULT_OK, resultIntent)
            finish() // Ferme Activity2 et retourne à Activity1
        }

        option1_b.setOnClickListener {
            returnResult("$code|$option2|$next2")
        }
        option2_b.setOnClickListener {
            returnResult("$code|$option3|$next3")
        }
        option3_b.setOnClickListener {
            returnResult("$code|$option4|$next4")
        }
        option4_b.setOnClickListener {
            returnResult("$code|$option5|$next5")
        }
    }
}