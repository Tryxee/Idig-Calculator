package fr.tryxee62dev.idigcalculatorapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import android.content.Intent
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import java.util.Locale
import kotlin.math.round

class MainActivity : ComponentActivity() {

    var language_selected = ""
    var calculate_count = 0
    var invisible = false

    var array_responses: MutableList<class_response> = mutableListOf()

    var IntentButton = Intent()
    var IntentDouble = Intent()
    var IntentSoftware = Intent()
    var IntentSoftware5 = Intent()
    var IntentResponse = Intent()

    // Déclaration du lanceur d'activité pour attendre un résultat
    private val activityResultLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val response = result.data?.getStringExtra("response") ?: ""
                //resultTextView.text = if (response) "Utilisateur a choisi OUI" else "Utilisateur a choisi NON"

                if (response == "restart"){
                    recreate()
                } else {
                    loop_query(response)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //setContentView(R.layout.activity_main)

        try {
            // Si tu veux ajouter un layout à MainActivity, décommente la ligne suivante
            // setContentView(R.layout.activity_main)

            init()

            // Démarre l'activité de sélection de langue
            val intentLang = Intent(this, LangActivity::class.java)
            activityResultLauncher.launch(intentLang)

            // Tous les Intents
            IntentButton = Intent(this, ButtonsActivity::class.java)
            IntentDouble = Intent(this, double_entryActivity::class.java)
            IntentSoftware = Intent(this, software_buttons_Activity::class.java)
            IntentSoftware5 = Intent(this, software_buttons_5_Activity::class.java)
            IntentResponse = Intent(this, ResponseActivity::class.java)

        } catch (e: Exception) {
            Toast.makeText(this, "Error in onCreate: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }

        /*fun get_intent(): Intent {
            return IntentButton
        }*/
    }

    var symbole_monnaie: String = ""
    var local_to_euro = 0.0
    var touch_2d_lite_cost = 6900
    var touch_2d_cost = 8500
    var connect_2d = 11690
    var connect_2d_project = 18900
    var connect_3d = 22500

    var current = class_codes()
    var next = class_codes()

    val scenarios = class_def_scenario()

    fun find_response(pcode: String, must_exist: Boolean): Double {
        for (resp in array_responses) {
            if (resp.code == pcode){
                val splittedResponseValue = resp.value.split("#")
                if (splittedResponseValue.size != 2) {
                    Toast.makeText(this, "find_response don't have 2 arguments", Toast.LENGTH_LONG).show()
                    return -1.0
                } else {
                    // Toast.makeText(this, "find_response, ${resp.value}", Toast.LENGTH_LONG).show()
                    try {
                        return splittedResponseValue[0].toDouble()
                    } catch (e : Exception) {
                        Toast.makeText(this, "find_response, ${resp.value} ,Error : ${e.message}", Toast.LENGTH_LONG).show()
                        return -1.0
                    }
                }
            }
        }
        if (must_exist) {
            Toast.makeText(this, "find_response don't found", Toast.LENGTH_LONG).show()
        }
        return -1.0
    }

    fun cost_product(pcode: String): Double {
        for (resp in array_responses) {
            if (resp.code == pcode){
                val softwares = "TOUCH 2D Lite|TOUCH 2D|CONNECT 2D+|CONNECT 2D PROJECT|CONNECT 3D"
                val softwareSplitted = softwares.split("|")
                if      (resp.value == softwareSplitted[0]) {
                    invisible = true
                    return touch_2d_lite_cost.toDouble()
                }
                else if (resp.value == softwareSplitted[1]) {
                    invisible = true
                    return touch_2d_cost.toDouble()
                }
                else if (resp.value == softwareSplitted[2]) {
                    invisible = true
                    return connect_2d.toDouble()
                }
                else if (resp.value == softwareSplitted[3]) {
                    invisible = false
                    return connect_2d_project.toDouble()
                }
                else if (resp.value == softwareSplitted[4]) {
                    invisible = false
                    return connect_3d.toDouble()
                }
                else {
                    Toast.makeText(this, "cost_product : Product out of array", Toast.LENGTH_LONG).show()
                    return -1.0
                }

            }
        }
        Toast.makeText(this, "find_response don't found", Toast.LENGTH_LONG).show()
        return -1.0
    }

    fun Double.round(decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10 }
        return round(this * multiplier) / multiplier
    }

    fun SendCalculResultsToActivity(D13: Double, D14: Double, D15: Double, D16: Double, D17: Double, D18: Double, D19: Double, D20: Double, D21: Double, D22: Double) {
        try {
            //Toast.makeText(this, "This is my Toast message!", Toast.LENGTH_LONG).show();
            IntentResponse.putExtra("D13", D13)
            IntentResponse.putExtra("D14", D14)
            IntentResponse.putExtra("D15", D15)
            IntentResponse.putExtra("D16", D16)
            IntentResponse.putExtra("D17", D17)
            IntentResponse.putExtra("D18", D18)
            IntentResponse.putExtra("D19", D19)
            IntentResponse.putExtra("D20", D20)
            IntentResponse.putExtra("D21", D21)
            IntentResponse.putExtra("D22", D22)
            IntentResponse.putExtra("lang", language_selected)
            IntentResponse.putExtra("invisible", invisible.toString())
            IntentResponse.putExtra("devise", symbole_monnaie)
            activityResultLauncher.launch(IntentResponse)

        } catch (e : Exception) {
            Toast.makeText(this, "SendCalculResultsToActivity, Error : ${e.message}", Toast.LENGTH_LONG).show();
        }
    }

    fun run_calcul(){
        var D2: Double = find_response("capital_investment", false)
        val D4: Double = find_response("survey_cost", false)
        val D5: Double = find_response("survey_implantation_number", false)
        val D6: Double = find_response("salaire", true)
        val D7: Double = find_response("pdg_taxes", true)/100
        val D8: Double = find_response("machine_price", true)
        val D9: Double = find_response("maintenance_price", true)
        val D10: Double = find_response("fuel_budget", true)
        val D11: Double = find_response("control_time", true)
        val D12: Double = find_response("ascents_descents_number", true)

        if (D2 == -1.0) {
            D2 = cost_product("choose_software")
            if (D2 < 1.0) {
                // Activity Error
                Toast.makeText(this, "Test D2 : D2 < 0", Toast.LENGTH_LONG).show()
                return
            }
        }

        val D13 = D4*D5
        val D14 = ((D6+D6*D7)/60)*D11*D12*6
        val D15 = (D8*0.66/6000)/60*D11*D12*6
        val D16 = (D9/1000)*(D11*D12*6/60)
        val D17 = (D10/(6*22))/60*D11*D12*6
        val D18 = D14+D15+D16+D17
        val D19 = (D2-D13)/D18
        val D20 = D19/22
        var D21 = 0.0
        var D22 = 0.0

        if (D20 <= 12) {
            D21 = (D2 / 12) * (12 - D20)
            D21.round(2)
        }

        if (D20 <= 24) {
            D22 = D2+((D2/12)*(12-D20))
            D22.round(2)
        }

        SendCalculResultsToActivity(D13, D14, D15, D16, D17, D18, D19, D20, D21, D22)

    }

    fun loop_query(response: String)
    {

        //setCurrentLocale(this, "en_US")

        var next_scenario = ""
        var query_type = ""
        var frame_label = ""
        var buttons_option = ""
        var query_code = ""

        val splittedResponse = response.split("|")
        if (splittedResponse[0] == "lang") {
            if (language_selected == "") {
                if (splittedResponse[0] == "lang" && splittedResponse[1] != "") {
                    language_selected = splittedResponse[1]
                    set_language(language_selected)
                } else if (splittedResponse[0] == "lang" && splittedResponse[1] == "") {
                    Toast.makeText(this, "Error : Language not selected !", Toast.LENGTH_LONG)
                        .show()
                    recreate()
                }
            } else {
                set_language(language_selected)
            }
        }
        else
        {
            // Traiter la réponse
            //ajout tableau reponse code_scenario, code_question, reponse
            val resp = class_response()
            resp.set_response(splittedResponse[0], splittedResponse[1])

            if (resp.code == "choose_software") {
                val softwares = "TOUCH 2D Lite|TOUCH 2D|CONNECT 2D+|CONNECT 2D PROJECT|CONNECT 3D"
                val softwareSplitted = softwares.split("|")
                if (resp.value == softwareSplitted[0] || resp.value == softwareSplitted[1] || resp.value == softwareSplitted[2]) {
                    invisible = true
                }
            }

            array_responses.add(resp)

            if (splittedResponse[2] == "calculate") {
                // Faire les calculs
                run_calcul()
            }
            else if (splittedResponse[2] != "")
            {
                // Alors c'est un choix multiple, on change de scénario.
                current.scenario = splittedResponse[2]
                current.query = ""
            }
            else {
                //response.code_question = current.query
                // response.response_value = splittedResponse[1]

                // On enchaine
                current.query = splittedResponse[0]   // déjà égale
                if (!findNextQuery(current, next))
                {
                    Toast.makeText(this, "Error : findNextQuery return false", Toast.LENGTH_LONG).show()
                }

                current = next
            }

        }


        val scenario = findScenario(current.scenario)

        if (scenario == null) {
            Toast.makeText(this, "Scénario non trouvé", Toast.LENGTH_LONG).show()
        }

        var query = findQuery(scenario, current.query)
        if (query == null) {
            println("Question non trouvé")
        }
        else
        {
            current.query = query.code

            // En fonction du scenario et de la question lancer le bon intent
            // En fonction du type de question afficher le controle
            // et attendre la validation de l'opérateur.
            query_type = query.query_type
            frame_label = query.label
            buttons_option = query.option
            next_scenario = query.next_step
            query_code = query.code

            Check_type(query_type, frame_label, buttons_option, next_scenario, query_code)
        }
    }

    fun Check_type(query_type: String, frame_label: String, buttons_options: String, next_possibilities: String, query_code: String) {

        val splitted_buttons_options = buttons_options.split("|") // split les options
        val splitted_next_scenario = next_possibilities.split("|") //récupérer code 2 prochains scenarios


        if (splitted_next_scenario[0] == "calculate") {
            if (calculate_count == 0 ) {
                calculate_count += 1
            } else {
             return
            }
        }
        if (query_type == "buttons") {
            try {
                //Toast.makeText(this, "This is my Toast message!", Toast.LENGTH_LONG).show();
                IntentButton.putExtra("frame_label", frame_label)
                IntentButton.putExtra("option1", splitted_buttons_options[0])
                IntentButton.putExtra("option2", splitted_buttons_options[1])
                IntentButton.putExtra("next1", splitted_next_scenario[0])
                IntentButton.putExtra("next2", splitted_next_scenario[1])
                IntentButton.putExtra("code", query_code)
                IntentButton.putExtra("lang", language_selected)
                activityResultLauncher.launch(IntentButton)

            } catch (e : Exception) {
                println(e.message)
            }
        } else if (query_type == "double_entry") {
            try {
                //Toast.makeText(this, "This is my Toast message!", Toast.LENGTH_LONG).show();
                IntentDouble.putExtra("frame_label", frame_label)
                IntentDouble.putExtra("next", next_possibilities)
                IntentDouble.putExtra("option", splitted_buttons_options[0])
                IntentDouble.putExtra("code", query_code)
                IntentDouble.putExtra("lang", language_selected)
                activityResultLauncher.launch(IntentDouble)

            } catch (e : Exception) {
                println(e.message)
            }
        } else if (query_type == "software_buttons") {
            try {
                if (language_selected == "en_US")
                {
                    IntentSoftware.putExtra("frame_label", frame_label)
                    IntentSoftware.putExtra("option2", splitted_buttons_options[1])
                    IntentSoftware.putExtra("option3", splitted_buttons_options[2])
                    IntentSoftware.putExtra("option4", splitted_buttons_options[3])
                    IntentSoftware.putExtra("option5", splitted_buttons_options[4])
                    IntentSoftware.putExtra("next2", splitted_next_scenario[1])
                    IntentSoftware.putExtra("next3", splitted_next_scenario[2])
                    IntentSoftware.putExtra("next4", splitted_next_scenario[3])
                    IntentSoftware.putExtra("next5", splitted_next_scenario[4])
                    IntentSoftware.putExtra("code", query_code)
                    IntentSoftware.putExtra("lang", language_selected)
                    activityResultLauncher.launch(IntentSoftware)
                }
                else
                {
                    //Toast.makeText(this, "This is my Toast message!", Toast.LENGTH_LONG).show();
                    IntentSoftware5.putExtra("frame_label", frame_label)
                    IntentSoftware5.putExtra("option1", splitted_buttons_options[0])
                    IntentSoftware5.putExtra("option2", splitted_buttons_options[1])
                    IntentSoftware5.putExtra("option3", splitted_buttons_options[2])
                    IntentSoftware5.putExtra("option4", splitted_buttons_options[3])
                    IntentSoftware5.putExtra("option5", splitted_buttons_options[4])
                    IntentSoftware5.putExtra("next1", splitted_next_scenario[0])
                    IntentSoftware5.putExtra("next2", splitted_next_scenario[1])
                    IntentSoftware5.putExtra("next3", splitted_next_scenario[2])
                    IntentSoftware5.putExtra("next4", splitted_next_scenario[3])
                    IntentSoftware5.putExtra("next5", splitted_next_scenario[4])
                    IntentSoftware5.putExtra("code", query_code)
                    IntentSoftware5.putExtra("lang", language_selected)
                    activityResultLauncher.launch(IntentSoftware5)
                }
            } catch (e : Exception) {
                println(e.message)
            }
        }
    }

    fun findScenario(code: String): class_scenario? {
        for (sce in scenarios.scenario_array) {
            if (code == sce.code) {
                return sce
            }
        }
        return null
    }

    fun findQuery(scenario: class_scenario?, current_code: String): class_question? {

        var next_scenario = ""
        var query_type = ""
        var frame_label = ""
        var buttons_option = ""

        if (scenario != null) {
            for (question in scenario.array_question) {
                if (current_code == "") {
                    return question
                }
                else if (current_code == question.code) {
                    return question
                }
            }
        }
        // Erreur
        return null
    }

    fun findNextQuery(current: class_codes, next: class_codes): Boolean {

        var next_scenario = ""
        var query_type = ""
        var frame_label = ""
        var buttons_option = ""

        // Parcours des scénarios

        var scenario : class_scenario?

        scenario = findScenario(current.scenario)
        if (scenario == null) {
        //Erreur
        }

        if (scenario != null) {
            for (iquestion in scenario.array_question.indices) {
                if (current.query == "") {
                    next.scenario = scenario.code
                    next.query = scenario.array_question[0].code

                    return true
                }

                if (current.query == scenario.array_question[iquestion].code) {
                    if (iquestion >= scenario.array_question.size - 1) {

                        next.scenario = scenario.array_question[iquestion].next_step
                        next.query = ""
                    } else {
                        next.scenario = scenario.code
                        next.query = scenario.array_question[iquestion + 1].code
                    }
                    return true
                }
            }
        }
        // Erreur
        return false
    }

    fun init()
    {
        scenarios.init()

        current.set_scenario("know_idig_investment")
        current.set_query("")

        next.set_scenario("")
        next.set_query("")
    }

    fun set_language(current_language: String) {



/*
        fun run_question(scenario: class_scenario?): String {

            var next_scenario = ""
            var query_type = ""
            var frame_label = ""
            var buttons_option = ""

            if (scenario != null) {
                for (question in scenario.array_question) {
                    // En fonction du type de question afficher le controle
                    // et attendre la validation de l'opérateur.

                    query_type = question.query_type
                    frame_label = question.label
                    buttons_option = question.option
                    next_scenario = question.next_step

                    Check_type(query_type, frame_label, buttons_option)

                }
            }
            return next_scenario
        }
        */

        if (current_language.lowercase() == Locale.FRANCE.toString().lowercase()) {
            symbole_monnaie = "€"
            local_to_euro = 1.0
            touch_2d_lite_cost = 6900
            touch_2d_cost = 8500
            connect_2d = 11690
            connect_2d_project = 18900
            connect_3d = 22500
        }
        else if (current_language.lowercase() == Locale.US.toString().lowercase()) {
            symbole_monnaie = "$"
            local_to_euro = 0.9229
            touch_2d_lite_cost = 0
            touch_2d_cost = 11550
            connect_2d = 14500
            connect_2d_project = 23000
            connect_3d = 26300
        }
        else if (current_language.lowercase() == Locale.GERMANY.toString().lowercase()) {
            symbole_monnaie = "€"
            local_to_euro = 1.0
            touch_2d_lite_cost = 6900
            touch_2d_cost = 8500
            connect_2d = 11690
            connect_2d_project = 18900
            connect_3d = 22500
        }
        else if (current_language.lowercase() == Locale.UK.toString().lowercase()) {
            symbole_monnaie = "£"
            local_to_euro = 1.1911
            touch_2d_lite_cost = 5865
            touch_2d_cost = 7225
            connect_2d = 9937
            connect_2d_project = 15725
            connect_3d = 17935
        }
        else if (current_language.lowercase() == "zz_zz") {
            symbole_monnaie = "€"
            local_to_euro = 1.0
            touch_2d_lite_cost = 6900
            touch_2d_cost = 8500
            connect_2d = 11690
            connect_2d_project = 18900
            connect_3d = 22500
        }
        /*else if (current_language.lowercase() == "es_es") {
            symbole_monnaie = "€"
            local_to_euro = 1.0
        }*/

        /*fun run(lang: String) {
            if (lang.lowercase() == Locale.FRANCE.toString().lowercase()) {
                fr.run()
            }
            else if (lang.lowercase() == Locale.US.toString().lowercase()) {
                us.run()
            }
            else if (lang.lowercase() == Locale.GERMANY.toString().lowercase()) {
                de.run()
            }
            else if (lang.lowercase() == Locale.UK.toString().lowercase()) {
                uk.run()
            }
            else if (lang.lowercase() == "es_es") {
                es.run()
            }
        }*/

        // val app = class_app()

        // app.init()
        /*var scenario = findScenario("capital_investment")?.code ?: "Scénario non trouvé"
        var next_code_scenario = ""

        do {
            next_code_scenario = run_question(scenario)
        } while (next_code_scenario != "calcul")*/

        /*
        do {
            val scenario = findScenario(next_code_scenario)

            if (scenario == null) {
                println("Scénario non trouvé")
                break
            }

            // Exécuter le scenario et retourner le prochain scénario.
            next_code_scenario = run_question(scenario)

            if(next_code_scenario == "") {
                println("error : next_code_scenario is null")
                break
            }

        } while (next_code_scenario != "calculate")
        if (next_code_scenario == "calculate") {
            //run_calcul()
        }
        */
    }
    class class_codes {
        var scenario : String = ""
        var query : String = ""

        fun set_scenario(code: String)
        {
            scenario = code
        }

        fun set_query(code: String)
        {
            query = code
        }
    }

    class class_response {
        var code: String = ""
        var value: String = ""

        fun set_response(key: String, pvalue: String) {
            code = key
            value = pvalue
        }
    }
}

//class class_pays {
//    var symbole_monnaie: String = ""
//    var local_to_euro = 0.0
//    val scenarios = class_def_scenario()
//    var next_step_choose: String = "" // Valeur retournée par les choix et text
//
//    fun init(symbol: String, taux: Double) {
//        symbole_monnaie = symbol
//        local_to_euro = taux
//    }
//
//    fun findScenario(code: String): class_scenario? {
//        for (sce in scenarios.scenario_array) {
//            if (code == sce.code) {
//                return sce
//            }
//        }
//        return null
//    }
//
//    fun Check_type(query_type: String, frame_label: String, buttons_options: String, next_possibilities: String) {
//
//        val splitted_next_scenario = next_possibilities.split("|") //récupérer code 2 prochains scenarios
//        val splitted_buttons_options = buttons_options.split("|") // split les options
//
//        if (query_type == "buttons") {
//            try {
//                //var theIntent = MainActivity().get_intent()
//
//                //Toast.makeText(context, "This is my Toast message!", Toast.LENGTH_LONG).show();
//                /*theIntent.putExtra("frame_label", frame_label)
//                theIntent.putExtra("option_yes", splitted_buttons_options[0])
//                theIntent.putExtra("option_no", splitted_buttons_options[1])
//                theIntent.putExtra("next1", splitted_next_scenario[0])
//                theIntent.putExtra("next2", splitted_next_scenario[1])*/
//                //startActivity(MainActivity().intent)
//            } catch (e : Exception) {
//                println(e.message)
//            }
//        } else if (query_type == "double_entry") {
//            //
//        } else if (query_type == "software_buttons") {
//            //
//        } else if (query_type == "survey_cost") {
//            //
//        }
//
//    }
//
//    fun run_question(scenario: class_scenario?): String {
//
//        var next_scenario = ""
//        var query_type = ""
//        var frame_label = ""
//        var buttons_option = ""
//
//        if (scenario != null) {
//            for (question in scenario.array_question) {
//
//                // En fonction du type de question afficher le controle
//                // et attendre la validation de l'opérateur.
//
//                query_type = question.query_type
//                frame_label = question.label
//                buttons_option = question.option
//                next_scenario = question.next_step
//
//                Check_type(query_type, frame_label, buttons_option, next_scenario)
//
//            }
//        }
//        return next_scenario
//    }
//
//    fun run()
//    {
//        scenarios.init()
//        /*var scenario = findScenario("capital_investment")?.code ?: "Scénario non trouvé"
//        var next_code_scenario = ""
//
//        do {
//            next_code_scenario = run_question(scenario)
//        } while (next_code_scenario != "calcul")*/
//        var next_code_scenario = "know_idig_investment"
//        do {
//            val scenario = findScenario(next_code_scenario)
//
//            if (scenario == null) {
//                println("Scénario non trouvé")
//                break
//            }
//
//            // Exécuter le scenario et retourner le prochain scénario.
//            next_code_scenario = run_question(scenario)
//
//            if(next_code_scenario == "") {
//                println("error : next_code_scenario is null")
//                break
//            }
//
//        } while (next_code_scenario != "calculate")
//        if (next_code_scenario == "calculate") {
//            //run_calcul()
//        }
//    }
//}
//
//class class_app{
//
//    //val pays = ArrayList<class_pays>()
//
//    /*
//    Locale.GERMANY = de_DE
//    Locale.US = en_US
//    Locale.FRANCE = fr_FR
//    Locale.UK = en_GB
//    */
//
//    val fr:class_pays = class_pays()
//    val de:class_pays = class_pays()
//    val us:class_pays = class_pays()
//    val uk:class_pays = class_pays()
//    val es:class_pays = class_pays()
//
//    fun init() {
//        // pays.add(fr)
//        // pays.add(de)
//        // pays.add(us)
//
//        fr.init("€", 1.0)
//        de.init("€", 1.0)
//        es.init("€", 1.0)
//        us.init("$", 0.9229)
//        uk.init("£", 1.1911)
//    }
//
//    /*
//    fun run(lang: String) {
//        if (lang.lowercase() == Locale.FRANCE.toString().lowercase()) {
//            fr.run()
//        }
//        else if (lang.lowercase() == Locale.US.toString().lowercase()) {
//            us.run()
//        }
//        else if (lang.lowercase() == Locale.GERMANY.toString().lowercase()) {
//            de.run()
//        }
//        else if (lang.lowercase() == Locale.UK.toString().lowercase()) {
//            uk.run()
//        }
//        else if (lang.lowercase() == "es_es") {
//            es.run()
//        }
//    }
//     */
//
//}
