package fr.tryxee62dev.idigcalculatorapp

class class_scenario(pcode: String) {
    var code: String = pcode
    //var array_question = ArrayList<class_question>()
    var array_question: MutableList<class_question> = mutableListOf()

    fun ajout_question(code: String, query_type: String, label: String, option: String, next: String) {
        val question = class_question()
        question.code = code
        question.query_type = query_type
        question.label = label
        question.option = option
        question.next_step = next

        array_question.add(question)
    }
}

class class_def_scenario {

    var scenario_array = ArrayList<class_scenario>()

    val know_idig_investment:class_scenario = class_scenario("know_idig_investment")
    val capital_investment:class_scenario = class_scenario("capital_investment")
    val choose_software:class_scenario = class_scenario("choose_software")
    val who_measure_control:class_scenario = class_scenario("who_measure_control")
    val survey_cost:class_scenario = class_scenario("survey_cost")
    val salaire_operator:class_scenario = class_scenario("salaire_operator")
    val salaire_rodman:class_scenario = class_scenario("salaire_rodman")

    fun init() {
        know_idig_investment.ajout_question("know_idig_investment", "buttons", "know_idig_investment", "option_yes|option_no", "capital_investment|choose_software")

        capital_investment.ajout_question("capital_investment", "double_entry", "capital_investment", "script_replace", "")
        capital_investment.ajout_question("choose_software", "software_buttons", "choose_software", "TOUCH 2D Lite|TOUCH 2D|CONNECT 2D+|CONNECT 2D PROJECT|CONNECT 3D", "who_measure_control|who_measure_control|who_measure_control|survey_cost|survey_cost")

        choose_software.ajout_question("choose_software", "software_buttons", "choose_software", "TOUCH 2D Lite|TOUCH 2D|CONNECT 2D+|CONNECT 2D PROJECT|CONNECT 3D", "who_measure_control|who_measure_control|who_measure_control|survey_cost|survey_cost")

        who_measure_control.ajout_question("who_control_measure", "buttons", "who_control_measure", "operator|rodman", "salaire_operator|salaire_rodman")

        survey_cost.ajout_question("survey_cost", "double_entry", "survey_cost", "example_price_survey", "")
        survey_cost.ajout_question("survey_implantation_number", "double_entry", "survey_implantation_number", "script_replace", "who_measure_control")

        salaire_operator.ajout_question("salaire", "double_entry", "salaire_operator", "example_price_operator", "")
        salaire_operator.ajout_question("pdg_taxes", "double_entry", "pdg_taxes", "example_price_pdg_taxes", "")
        salaire_operator.ajout_question("machine_price", "double_entry", "machine_price", "example_price_machine_price", "")
        salaire_operator.ajout_question("maintenance_price", "double_entry", "maintenance_price", "example_price_maintenance_price", "")
        salaire_operator.ajout_question("fuel_budget", "double_entry", "fuel_budget", "example_price_fuel_budget", "")
        salaire_operator.ajout_question("control_time", "double_entry", "control_time", "example_time_control_time", "")
        salaire_operator.ajout_question("ascents_descents_number", "double_entry", "ascents_descents_number_operator", "example_number_ascents_descents_operator", "calculate")

        salaire_rodman.ajout_question("salaire", "double_entry", "salaire_rodman", "example_price_rodman", "")
        salaire_rodman.ajout_question("pdg_taxes", "double_entry", "pdg_taxes", "example_price_pdg_taxes", "")
        salaire_rodman.ajout_question("machine_price", "double_entry", "machine_price", "example_price_machine_price", "")
        salaire_rodman.ajout_question("maintenance_price", "double_entry", "maintenance_price", "example_price_maintenance_price", "")
        salaire_rodman.ajout_question("fuel_budget", "double_entry", "fuel_budget", "example_price_fuel_budget", "")
        salaire_rodman.ajout_question("control_time", "double_entry", "control_time", "example_time_control_time", "")
        salaire_rodman.ajout_question("ascents_descents_number", "double_entry", "ascents_descents_number_roadman", "example_number_ascents_descents_roadman", "calculate")

        scenario_array.add(know_idig_investment)
        scenario_array.add(capital_investment)
        scenario_array.add(choose_software)
        scenario_array.add(who_measure_control)
        scenario_array.add(survey_cost)
        scenario_array.add(salaire_operator)
        scenario_array.add(salaire_rodman)
    }
}

class class_question {
    var code = ""
    var query_type = ""
    var label = ""
    var option = ""
    var next_step = ""
    var entered_value = 0.0
}